#include "lab03.h"

#include <xc.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL
#include <libpic30.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

/*
 * DAC code
 */

#define DAC_CS_TRIS TRISDbits.TRISD8
#define DAC_SDI_TRIS TRISBbits.TRISB10
#define DAC_SCK_TRIS TRISBbits.TRISB11
#define DAC_LDAC_TRIS TRISBbits.TRISB13
    
#define DAC_CS_PORT PORTDbits.RD8
#define DAC_SDI_PORT PORTBbits.RB10
#define DAC_SCK_PORT PORTBbits.RB11
#define DAC_LDAC_PORT PORTBbits.RB13

#define DAC_SDI_AD1CFG AD1PCFGLbits.PCFG10
#define DAC_SCK_AD1CFG AD1PCFGLbits.PCFG11
#define DAC_LDAC_AD1CFG AD1PCFGLbits.PCFG13

#define DAC_SDI_AD2CFG AD2PCFGLbits.PCFG10
#define DAC_SCK_AD2CFG AD2PCFGLbits.PCFG11
#define DAC_LDAC_AD2CFG AD2PCFGLbits.PCFG13

uint16_t state_output = 0;
double v_out[3];
v_out[0] = 1;
v_out[1] = 2.5;
v_out[2] = 3.5;
uint16_t timer_period[3];
timer_period[0] = 25000;
timer_period[1] = 100000;
timer_period[2] = 50000;

void dac_initialize()
{
    // set AN10, AN11 AN13 to digital mode
    // this means AN10 will become RB10, AN11->RB11, AN13->RB13
    // see datasheet 11.3
    // set RD8, RB10, RB11, RB13 as output pins
    SETBIT(DAC_SDI_AD1CFG); //AN10 -> RB10
    SETBIT(DAC_SDI_AD2CFG);
    CLEARBIT(DAC_SDI_TRIS); 
    
    SETBIT(DAC_SCK_AD1CFG); //AN11 -> RB11
    SETBIT(DAC_SCK_AD2CFG);
    CLEARBIT(DAC_SCK_TRIS);
    
    SETBIT(DAC_LDAC_AD1CFG); //AN13 -> RB13
    SETBIT(DAC_LDAC_AD2CFG);
    CLEARBIT(DAC_LDAC_TRIS);
    
    SETBIT(DAC_CS_TRIS);
    CLEARBIT(DAC_CS_TRIS);

    // set default states
    // CS pin: high (idle state), SDI: low, SCK: low, LDAC: high
    DAC_CS_PORT = 1;
    DAC_SDI_PORT = 0;
    DAC_SCK_PORT = 0;
    DAC_LDAC_PORT = 1;    
}

#define FCY_EXT   32768UL

#define TCKPS_1   0x00
#define TCKPS_8   0x01
#define TCKPS_64  0x02
#define TCKPS_256 0x03

void timer_initialize()
{
    // Enable RTC Oscillator -> this effectively does OSCCONbits.LPOSCEN = 1
    // but the OSCCON register is lock protected. That means you would have to 
    // write a specific sequence of numbers to the register OSCCONL. After that 
    // the write access to OSCCONL will be enabled for one instruction cycle.
    // The function __builtin_write_OSCCONL(val) does the unlocking sequence and
    // afterwards writes the value val to that register. (OSCCONL represents the
    // lower 8 bits of the register OSCCON)
    __builtin_write_OSCCONL(OSCCONL | 2);
    // configure timer

    // disable timers
    T1CONbits.TON = 0;

    // set prescaler 1:256
    T1CONbits.TCKPS = 0b11;

    // select internal clock source with 12.8MHz
    T1CONbits.TCS = 0;

    // set gated timer mode -> don't use gating
    T1CONbits.TGATE = 0;

    // set timer periods
    // after prescaler counts with 50000Hz. 
    // delay of 500ms: PR = 25000, 2000ms: PR = 100000, and 1000ms: PR = 50000,
    PR1 = timer_period[0]; 

    // reset timer value
    TMR1 = 0x00;

    // set interrupt priority
    IPC0bits.T1IP = 0x01;

    // clear interrupt flags
    CLEARBIT(IFS0bits.T1IF);

    // enable interrupts
    IEC0bits.T1IE = 1;
    
    // start timer
    T1CONbits.TON = 1;    
}

// interrupt service routine
void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T1Interrupt(void)
{ // invoked every 500ms, 2000ms, 1000ms
    state_output += 1;
    if (state_output > 2){
        TOGGLELED(LED1_PORT);
        state_output = 0;
    }

    PR1 = timer_period[state_output];
    IFS0bits.T1IF = 0; // Clear the interrupt flag
}

void main_loop()
{
    // print assignment information
    lcd_printf("Lab03: DAC");
    lcd_locate(0, 1);
    lcd_printf("Group: Lab 3 Group 2");
    //int v_out_1 = 2000;     // 4096/2.048 = 2000mV
    
    while(TRUE)
    {
        //DAC_SDI_PORT = 0010011111010000;
            send_vout(v_out[state_output]);
    }
}

void send_vout(int voltage_signal)
{

    // generate bit array
    int i = 0;
    int bit_seq[12];
    while (i<12){
        bit_seq[i] = voltage_signal >> i & 1;
    }
            
    // set CS port to low
    DAC_CS_PORT = 0;

    // initialize bit sequence
    // send bit 15 - DAC_A
    DAC_SDI_PORT = 0;
    cycle_sck();

    // bit 14 - dont' care
    cycle_sck();

    // bit 13 
    if {voltage_signal <= 2}{
        DAC_SDI_PORT = 1; // set gain = 1
    }    
    else if {voltage_signal <= 4}{
        DAC_SDI_PORT = 0; // set gain = 2
        voltage_signal /= 2;
    }
    cycle_sck();

    // bits 12 - 0 data bits
    uint16_t i = 11;
    int volt_bits = (int)voltage_signal
    for (i>=0; i--){
        DAC_SDI_PORT = (volt_bits >> i) & 1;
        cycle_sck();
    }

    CLEARBIT(DAC_CS_PORT);
    Nop();
    CLEARBIT(DAC_SDI_PORT);
    Nop();
    CLEARBIT(DAC_LDAC_PORT);
    Nop();
    SETBIT(DAC_LDAC_PORT);
    Nop();
}

void cycle_sck(){
    Nop();
    SETBIT(DAC_SCK_PORT);
    Nop();
    CLEARBIT(DAC_SCK_PORT);
    Nop();
}