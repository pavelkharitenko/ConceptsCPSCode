#include "lab03.h"

#include <xc.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL
#include <libpic30.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

/*
 * DAC code
 */

#define DAC_CS_TRIS TRISDbits.TRISD8
#define DAC_SDI_TRIS TRISBbits.TRISB10
#define DAC_SCK_TRIS TRISBbits.TRISB11
#define DAC_LDAC_TRIS TRISBbits.TRISB13
    
#define DAC_CS_PORT PORTDbits.RD8
#define DAC_SDI_PORT PORTBbits.RB10
#define DAC_SCK_PORT PORTBbits.RB11
#define DAC_LDAC_PORT PORTBbits.RB13

#define DAC_SDI_AD1CFG AD1PCFGLbits.PCFG10
#define DAC_SCK_AD1CFG AD1PCFGLbits.PCFG11
#define DAC_LDAC_AD1CFG AD1PCFGLbits.PCFG13

#define DAC_SDI_AD2CFG AD2PCFGLbits.PCFG10
#define DAC_SCK_AD2CFG AD2PCFGLbits.PCFG11
#define DAC_LDAC_AD2CFG AD2PCFGLbits.PCFG13

volatile uint8_t state_output = 0;
volatile uint8_t time_counter = 0;
double v_out[3] = {1, 2.5, 3.5};

void dac_initialize()
{
    // set AN10, AN11 AN13 to digital mode
    // this means AN10 will become RB10, AN11->RB11, AN13->RB13
    // see datasheet 11.3
    // set RD8, RB10, RB11, RB13 as output pins
    SETBIT(DAC_SDI_AD1CFG); //AN10 -> RB10
    SETBIT(DAC_SDI_AD2CFG);
    CLEARBIT(DAC_SDI_TRIS); 
    
    SETBIT(DAC_SCK_AD1CFG); //AN11 -> RB11
    SETBIT(DAC_SCK_AD2CFG);
    CLEARBIT(DAC_SCK_TRIS);
    
    SETBIT(DAC_LDAC_AD1CFG); //AN13 -> RB13
    SETBIT(DAC_LDAC_AD2CFG);
    CLEARBIT(DAC_LDAC_TRIS);
    
    SETBIT(DAC_CS_TRIS);
    CLEARBIT(DAC_CS_TRIS);

    // set default states
    // CS pin: high (idle state), SDI: low, SCK: low, LDAC: high
    DAC_CS_PORT = 1;
    DAC_SDI_PORT = 0;
    DAC_SCK_PORT = 0;
    DAC_LDAC_PORT = 1;    
}

#define FCY_EXT   32768UL

#define TCKPS_1   0x00
#define TCKPS_8   0x01
#define TCKPS_64  0x02
#define TCKPS_256 0x03

void timer_initialize()
{
    // Enable RTC Oscillator -> this effectively does OSCCONbits.LPOSCEN = 1
    // but the OSCCON register is lock protected. That means you would have to 
    // write a specific sequence of numbers to the register OSCCONL. After that 
    // the write access to OSCCONL will be enabled for one instruction cycle.
    // The function __builtin_write_OSCCONL(val) does the unlocking sequence and
    // afterwards writes the value val to that register. (OSCCONL represents the
    // lower 8 bits of the register OSCCON)
    __builtin_write_OSCCONL(OSCCONL | 2);

    // disable timers
    T2CONbits.TON = 0;
    
    T2CONbits.TCS = 0;  // select internal clock source with 12.8MHz
    T2CONbits.TGATE = 0;    // disable gating
    T2CONbits.TCKPS = 0b11; // prescaler 1:256, 50000Hz. 
    TMR2 = 0x00;    // clear timer
    
    // set period
    // delay of 500ms: PR = 25000, 2000ms: PR = 100000, and 1000ms: PR = 50000
    PR2 = 25000;
 
    IPC1bits.T2IP = 0x01;   // set interrupt priority
    IFS0bits.T2IF = 0;      // clear timer interrupt flag
    IEC0bits.T2IE = 1;      // enable timer interrupt
    
    // start timer
    T2CONbits.TON = 1;
}

// interrupt service routine
void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T2Interrupt(void)
{ // invoked every 500ms, 2000ms, 1000ms
    if (time_counter == 0){
        state_output ++;
    }
    else if (time_counter == 4){
        state_output ++;
    }
    else if (time_counter == 6){
        state_output = 0;
        TOGGLELED(LED1_PORT);
    }
    time_counter = (time_counter + 1) % 7;
    
    IFS0bits.T2IF = 0; // Clear interrupt flag
}
    
void main_loop()
{
    // print assignment information
    lcd_printf("Lab03: DAC");
    lcd_locate(0, 1);
    lcd_printf("Group: Lab 3 Group 2");
    
    
    while(TRUE)
    {
        send_vout(v_out[state_output]);
    }
}

void send_vout(double voltage_signal){    
    // set CS port to low
    DAC_CS_PORT = 0;

    // initialize bit sequence
    // send bit 15 - DAC_A
    DAC_SDI_PORT = 0;
    cycle_sck();

    // bit 14 - dont care
    cycle_sck();

    // bit 13 
    if (voltage_signal <= 2){
        DAC_SDI_PORT = 1; // set gain = 1 (max voltage = 2.048)
    }    
    else if (voltage_signal <= 4){
        DAC_SDI_PORT = 0; // set gain = 2 
        voltage_signal /= 2;
    }
    cycle_sck();
    
    // bit 12 shutdown if voltage is 0
    DAC_SDI_PORT = voltage_signal != 0;
    cycle_sck();

    // bits 11 - 0 data bits
    voltage_signal = voltage_signal * 2000; // 4096/2.048 = 2000
    uint16_t volt_bits = (uint16_t)voltage_signal;
    
    int8_t i;
    for (i=11; i>=0; i--){
        DAC_SDI_PORT = (volt_bits >> i) & 1;
        cycle_sck();
    }   

    SETBIT(DAC_CS_PORT);
    CLEARBIT(DAC_SDI_PORT);
    Nop();
    CLEARBIT(DAC_LDAC_PORT);
    Nop();
    SETBIT(DAC_LDAC_PORT);
    Nop();
    CLEARBIT(DAC_CS_PORT);
    Nop();

}

void cycle_sck(){
    Nop();
    SETBIT(DAC_SCK_PORT);
    Nop();
    CLEARBIT(DAC_SCK_PORT);
    Nop();
}